-- TASK1-Customer Risk Analysis
SELECT c.customer_id,c.name,c.credit_score,l.loan_id,l.loan_amount,l.default_risk
FROM customer_table c JOIN loan_table l ON c.customer_id = l.customer_id WHERE c.credit_score < (SELECT AVG(credit_score) FROM customer_table) AND l.default_risk = 'High';


-- TASK-2:Loan Purpose Insights
SELECT loan_purpose, COUNT(*) AS loan_count, SUM(loan_amount) AS total_loan_amount
FROM loan_table
GROUP BY loan_purpose
ORDER BY loan_count DESC, total_loan_amount DESC;

-- Task 3: High-Value Transactions
SELECT trans.transaction_id,
    trans.loan_id,
    trans.customer_id,
    trans.transaction_date,
    trans.transaction_amount,
    trans.transaction_type,
    trans.payment_method,
    trans.status,
    trans.remarks,
    loan.loan_amount,
    (loan.loan_amount * 0.3) AS threshold_amount
FROM transaction_table trans
JOIN loan_table loan
ON trans.loan_id = loan.loan_id
WHERE  trans.transaction_amount > (loan.loan_amount * 0.3);


-- Task 4: Missed EMI Count
SELECT loan_id, COUNT(*) AS missed_emi_count FROM transaction_table WHERE  transaction_type LIKE '%Missed%' GROUP BY  loan_id ;
SELECT loan_id, COUNT(*) AS missed_emi_count FROM transaction_table WHERE  transaction_type LIKE '%Missed%' GROUP BY  loan_id HAVING COUNT(*) > 2;

-- Task 5: Regional Loan Distribution
SELECT  SUBSTRING(c.address, LENGTH(c.address) -8, 3) as myaddress, COUNT(l.loan_id) AS loan_count FROM customer_table c JOIN loan_table l
ON  c.customer_id = l.customer_id GROUP BY  myaddress ORDER BY loan_count DESC;

-- Task 6: Loyal Customers
SELECT 
    c.customer_id,
    c.name,
    COUNT(l.loan_id) AS total_loans,
    SUM(l.loan_amount) AS total_loan_amount,
    AVG(l.interest_rate) AS avg_interest_rate,
    MAX(l.default_risk) AS max_default_risk
FROM customer_table c
JOIN loan_table l
ON c.customer_id = l.customer_id
WHERE  c.customer_since < DATE_SUB(CURDATE(), INTERVAL 5 YEAR)
GROUP BY  c.customer_id, c.name;

-- Task 7: High-Performing Loans keeping like as ayment because p is capital and small both
SELECT  loan_id, COUNT(*) AS successful_emi_count
FROM transaction_table
WHERE transaction_type LIKE '%ayment%' AND status = 'Successful'
GROUP BY loan_id ORDER BY successful_emi_count DESC;

-- Task 8: Age-Based Loan Analysis
SELECT CASE 
WHEN ct.age BETWEEN 18 AND 25 THEN '18-25'
WHEN ct.age BETWEEN 26 AND 35 THEN '26-35'
WHEN ct.age BETWEEN 36 AND 45 THEN '36-45'
WHEN ct.age BETWEEN 46 AND 55 THEN '46-55'
WHEN ct.age BETWEEN 56 AND 65 THEN '56-65'
ELSE '66+'
END AS age_bracket, SUM(lt.loan_amount) AS total_loan_amount, AVG(lt.loan_amount) AS average_loan_amount
FROM customer_table ct JOIN loan_table lt ON  ct.customer_id = lt.customer_id GROUP BY  age_bracket ORDER BY  age_bracket;
 
 

-- Task 9: Seasonal Transaction Trends
SELECT YEAR(STR_TO_DATE(transaction_date, '%m/%d/%Y %H:%i')) AS year,
MONTH(STR_TO_DATE(transaction_date, '%m/%d/%Y %H:%i')) AS month,
COUNT(*) AS transaction_count
FROM  transaction_table WHERE  transaction_date IS NOT NULL
GROUP BY year, month
ORDER BY  year, month;
 
 
 -- Task 10: Repayment History Analysis
SELECT loan_id,COUNT(*) AS successful_emi_count,RANK() OVER (ORDER BY COUNT(*) DESC) AS repayment_rank
FROM transaction_table WHERE transaction_type = 'EMI Payment' AND status = 'Successful' GROUP BY loan_id;
    
-- Task 11: Credit Score vs. Loan Amount
SELECT CASE 
WHEN c.credit_score BETWEEN 0 AND 300 THEN '0-300'
WHEN c.credit_score BETWEEN 301 AND 500 THEN '301-500'
WHEN c.credit_score BETWEEN 501 AND 600 THEN '501-600'
WHEN c.credit_score BETWEEN 601 AND 700 THEN '601-700'
WHEN c.credit_score BETWEEN 701 AND 800 THEN '701-800'
WHEN c.credit_score BETWEEN 801 AND 900 THEN '801-900'
END AS credit_score_range, AVG(l.loan_amount) AS average_loan_amount
FROM customer_table c JOIN loan_table l ON c.customer_id = l.customer_id GROUP BY credit_score_range ORDER BY credit_score_range;
    

-- Task 12: Top Borrowing Regions
SELECT c.address,SUM(l.loan_amount) AS total_loan_amount,COUNT(l.loan_id) AS loan_count FROM customer_table c JOIN loan_table l
ON c.customer_id = l.customer_id GROUP BY c.address ORDER BY total_loan_amount DESC;
    
    













